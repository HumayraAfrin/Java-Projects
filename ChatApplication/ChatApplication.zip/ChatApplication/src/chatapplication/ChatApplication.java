package chatapplication;

public class ChatApplication {

    public static void main(String[] args) {
        
    }
    
}
